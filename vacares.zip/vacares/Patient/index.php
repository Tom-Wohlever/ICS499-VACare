<?php
  $content = '<div class="row">
                <div class="col-xs-12">
                <div class="box">
                  <div class="box-header">
                    <h3 class="box-title">Patients Information</h3>
                  </div>
                  <er -->
                  <div class="bo!-- /.box-headx-body">
                    <table id="patients" class="table table-bordered table-hover">
                      <thead>
                      <tr>
                        <th>Diagnosis</th>
                        <th>Prescriptions</th>
                      </tr>
                      </thead>
                      <tbody>
                      </tbody>
                      <tfoot>
                      <tr>
                       <th>Diagnosis</th>
                       <th>Prescriptions</th>
                      </tr>
                      </tfoot>
                    </table>
                  </div>
                  <!-- /.box-body -->
                </div>
                <!-- /.box -->
              </div>
            </div>';
  include('../master.php');
?>
<!-- page script -->
<script>
  $(document).ready(function(){
    var url = "../api/patient/patient_read.php";
    $.ajax({
        type: "GET",
        url: url,
        dataType: "json",
        success: function(data) {
            var response="";
            for(var user in data){
                response += "<tr>"+
                "<td>"+data[user].Diagnosis+"</td>"+
                "<td>"+data[user].Presrptions+"</td>"+
                "</tr>";
            }
            $(response).appendTo($("#patients"));
        }
    });
  });
</script>