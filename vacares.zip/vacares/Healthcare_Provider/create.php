<?php 
  $content = '<div class="row">
                <!-- left column -->
                <div class="col-md-12">
                  <!-- general form elements -->
                  <div class="box box-primary">
                    <div class="box-header with-border">
                      <h3 class="box-title">Add Provider</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form">
                      <div class="box-body">
                        <div class="form-group">
                          <label for="exampleFirstName1">First Name</label>
                          <input type="text" class="form-control" id="VA_Employee_Name_First" placeholder="First Name">
                        </div>
                        <div class="form-group">
                          <label for="exampleLastName1">Last Name</label>
                          <input type="text" class="form-control" id="VA_Employee_Name_Last" placeholder="Last Name">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputTitle1">Title</label>
                          <input type="text" class="form-control" id="Job_Title" placeholder="Ex: Clinic Admin">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputStreet1">Street Address</label>
                          <input type="text" class="form-control" id="Address_Street" placeholder="Ex: 1234 Baker St. N">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputCity1">City</label>
                          <input type="text" class="form-control" id="Address_City" placeholder="Ex: Minneapolis">
                        </div>
						            <div class="form-group">
                          <label for="exampleInputState1">State</label>
                          <input type="text" class="form-control" id="Address_State" placeholder="Ex: MN">
                        </div>
                      </div>
                      <!-- /.box-body -->
                      <div class="box-footer">
                        <input type="button" class="btn btn-primary" onClick="AddProvider()" value="Submit"></input>
                      </div>
                    </form>
                  </div>
                  <!-- /.box -->
                </div>
              </div>';
              
  include('../master.php');
?>
<script>
  function AddProvider(){
        $.ajax(
        {
            type: "POST",
            url: '../api/healthcare_provider/create.php',
            dataType: 'json',
            data: {
                Healthcare_Provider_Name_First: $("#Healthcare_Provider_Name_First").val(),
                Healthcare_Provider_Name_Last: $("#Healthcare_Provider_Name_Last").val(),        
                Job_Title: $("#Job_Title").val(),
                Address_Street: $("#Address_Street").val(),
                Address_City: $("#Address_City").val(),
                Address_State: $("#Address_State").val()
            },
            error: function (result) {
                alert(result.responseText);
            },
            success: function (result) {
                if (result['status'] == true) {
                    alert("Successfully Added New Provider!");
                    window.location.href = '/vacares/healthcare_provider';
                }
                else {
                    alert(result['message']);
                }
            }
        });
    }
</script>