<?php
  $content = '<div class="row">
                <!-- left column -->
                <div class="col-md-12">
                  <!-- general form elements -->
                  <div class="box box-primary">
                    <div class="box-header with-border">
                      <h3 class="box-title">Update Employee</h3>
                    </div>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form">
                      <div class="box-body">
                        <div class="form-group">
                          <label for="exampleFirstName1">First Name</label>
                          <input type="text" class="form-control" id="VA_Employee_Name_First" placeholder="First Name">
                        </div>
                        <div class="form-group">
                          <label for="exampleLastName1">Last Name</label>
                          <input type="text" class="form-control" id="VA_Employee_Name_Last" placeholder="Last Name">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputTitle1">Title</label>
                          <input type="text" class="form-control" id="Job_Title" placeholder="Ex: Web Admin">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputStreet1">Street Address</label>
                          <input type="text" class="form-control" id="Address_Street" placeholder="Ex: 1234 Baker St. N">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputCity1">City</label>
                          <input type="text" class="form-control" id="Address_City" placeholder="Ex: Minneapolis">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputState1">State</label>
                          <input type="text" class="form-control" id="Address_State" placeholder="Ex: MN">
                        </div>
                      </div>
                      <!-- /.box-body -->
                      <div class="box-footer">
                        <input type="button" class="btn btn-primary" onClick="UpdateEmployee()" value="Update"></input>
                      </div>
                    </form>
                  </div>
                  <!-- /.box -->
                </div>
              </div>';
  include('../master.php');
?>
<script>
    $(document).ready(function(){
        $.ajax({
            type: "GET",
            url: "../api/va_employee/read_single.php?id=<?php echo $_GET['VA_Employee_Name_Last']; ?>",
            dataType: "json",
            success: function(data) {
                $('#VA_Employee_Name_First').val(data['VA_Employee_Name_First']);
                $('#VA_Employee_Name_Last').val(data['VA_Employee_Name_Last']);
                $('#Job_Title').val(data['Job_Title']);
                $('#Address_Street').val(data['Address_Street']);
                $('#Address_City').val(data['Address_City']);
                $('#Address_State').val(data['Address_State']);
            },
            error: function (result) {
                console.log(result);
            },
        });
    });
    function UpdateEmployee(){
        $.ajax(
        {
            type: "POST",
            url: "../api/va_employee/update.php",
            dataType: 'json',
            data: {
                VA_Employee_Name_Last: <?php echo $_GET['VA_Employee_Name_Last']; ?>,
                VA_Employee_Name_First: $("#VA_Employee_Name_First").val(),     
                Job_Title: $("#Job_Title").val(),
                Address_Street: $("#Address_Street").val(),
                Address_City: $("#Address_City").val(),
                Address_State: $("#Address_State").val()
            },
            error: function (result) {
                alert(result.responseText);
            },
            success: function (result) {
                if (result['status'] == true) {
                    alert("Successfully Updated Employee!");
                    window.location.href = '/vacares/va_employee';
                }
                else {
                    alert(result['message']);
                }
            }
        });
    }
</script>