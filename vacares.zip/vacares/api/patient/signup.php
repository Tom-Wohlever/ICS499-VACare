<?php
 
// get database connection
include_once '../config/database.php';
 
// instantiate user object
include_once '../objects/patient.php';
 
$database = new Database();
$db = $database->getConnection();
 
$patient = new Patient($db);
 
// set user property values
$patient->Patient_Name_First = $_POST['Patient_Name_First'];
$patient->Patient_Name_Last = $_POST['Patient_Name_Last'];
$patient->Rank = $_POST['Rank'];
$patient->Branch = $_POST['Branch'];
$patient->Component = $_POST['Component'];
$patient->Address_Street = $_POST['Address_Street'];
$patient->Address_City = $_POST['Address_City'];
$patient->Address_State = $_POST['Address_State'];
$patient->Distance = $_POST['Distance'];
$patient->Username = $_POST['Username'];
$patient->Password = $_POST['Password'];

// create the user
if($patient->signup()){
    $patient_arr=array(
        "status" => true,
        "message" => "Successfully Signup!",
        "Patient_Name_First" => $patient->Patient_Name_First,
        "Patient_Name_Last" => $patient->Patient_Name_Last,
        "Rank" => $patient->Rank,
        "Branch" => $patient->Branch,
        "Component" => $patient->Component,
        "Address_Street" => $patient->Address_Street,
        "Address_City" => $patient->Address_City,
        "Address_State" => $patient->Address_State,
        "Distance" => $patient->Distance,
        "Username" => $patient->Username,
        "Password" => $patient->Password
    );
}
else {
    $patient_arr=array(
        "status" => false,
        "message" => "User already exists!"
    );
}
print_r(json_encode($patient_arr));
?>