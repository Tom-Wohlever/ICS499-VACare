<?php
// include database and object files
include_once '../config/database.php';
include_once '../objects/healthcare_provider.php';
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare employee object
$healthcare_provider = new Healthcare_Provider($db);
 
// set employee property values
$healthcare_provider->Healthcare_Provider_Name_First = $_POST['Healthcare_Provider_Name_First'];
$healthcare_provider->Healthcare_Provider_Name_Last = $_POST['Healthcare_Provider_Name_Last'];
$healthcare_provider->Job_Title = $_POST['Job_Title'];
$healthcare_provider->Address_Street = $_POST['Address_Street'];
$healthcare_provider->Address_City = $_POST['Address_City'];
$healthcare_provider->Address_State = $_POST['Address_State'];

// create the patient
if($healthcare_provider->create()){
    $healthcare_provider_arr=array(
        "status" => true,
        "message" => "Successfully Signup!",
        "Healthcare_Provider_Name_First" => $healthcare_provider->Healthcare_Provider_Name_First,
        "Healthcare_Provider_Name_Last" => $healthcare_provider->Healthcare_Provider_Name_Last,
        "Job_Title" => $healthcare_provider->Job_Title,
        "Address_Street" => $healthcare_provider->Address_Street,
        "Address_City" => $healthcare_provider->Address_City,
        "Address_State" => $healthcare_provider->Address_State
    );
}
else{
    $healthcare_provider_arr=array(
        "status" => false,
        "message" => "Healthcare Provider already exists!"
    );
}
print_r(json_encode($healthcare_provider_arr));
?>