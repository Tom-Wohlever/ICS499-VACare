<?php
// include database and object files
include_once '../config/database.php';
include_once '../objects/va_employee.php';

// get database connection
$database = new Database();
$db = $database->getConnection();

// prepare patient object
$va_employee = new VA_Employee($db);
// set ID property of employee to be edited
$va_employee->VA_Employee_Name_Last = isset($_GET['VA_Employee_Name_Last']) ? $_GET['VA_Employee_Name_Last'] : die();
// read the details of employee to be edited
$stmt = $va_employee->read_single();
if($stmt->rowCount() > 0){
    // get retrieved row
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // create array
    $va_employee_arr=array(
        "VA_Employee_Name_First" => $row['VA_Employee_Name_First'],
        "VA_Employee_Name_Last" => $row['VA_Employee_Name_Last'],
        "Job_Title" => $row['Job_Title'],
        "Address_Street" => $row['Address_Street'],
        "Address_City" => $row['Address_City'],
        "Address_State" => $row['Address_State']
    );
}
// make it json format
print_r(json_encode($va_employee_arr));
?>