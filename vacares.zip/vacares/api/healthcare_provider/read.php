<?php
// include database and object files
include_once '../config/database.php';
include_once '../objects/healthcare_provider.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare provider object
$healthcare_provider = new Healthcare_Provider($db);

// query provider
$stmt = $healthcare_provider->read();
$num = $stmt->rowCount();
// check if more than 0 record found
if($num>0){
 
    // providers array
    $healthcare_provider_arr=array();
    $healthcare_provider_arr["healthcare_provider"]=array();
 
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        $healthcare_provider_item=array(
            "Healthcare_Provider_Name_First" => $Healthcare_Provider_Name_First,
            "Healthcare_Provider_Name_Last" => $Healthcare_Provider_Name_Last,
            "Job_Title" => $Job_Title,
            "Address_Street" => $Address_Street,
            "Address_City" => $Address_City,
            "Address_State" => $Address_State
        );
        array_push($healthcare_providers_arr["healthcare_providers"], $healthcare_provider_item);
    }
 
    echo json_encode($healthcare_providers_arr["healthcare_providers"]);
}
else{
    echo json_encode(array());
}
?>