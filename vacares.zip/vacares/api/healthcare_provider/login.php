    <?php
    // include database and object files
    include_once '../config/database.php';
    include_once '../objects/healthcare_provider.php';
    include_once '../objects/patient.php';
    include_once '../objects/va_employee.php';
    include_once '../objects/user.php';

    // get database connection
    $database = new Database();
    $db = $database->getConnection();

    // prepare user object
    $healthcare_provider = new Healthcare_Provider($db);
    $patient = new Patient($db);
    $va_employee = new VA_Employee($db);
    $user = new User($db);

    // store ID property of user to be edited
    $name = isset($_GET['Username']) ? $_GET['Username'] : die();
    $pass = isset($_GET['Password']) ? $_GET['Password'] : die();

    // read the details of user to be edited
    $stmt1 = $healthcare_provider->login();
    $stmt2 = $patient->login();
    $stmt3 = $va_employee->login();

    $stmt4 = $user->login();

    if($stmt4->rowCount() == false) {

        header("Location: ../../VA_Employee/index.php");
            exit;
        
        
        if($stmt1->rowCount() > 0) {
            // set ID property of user to be edited
            $healthcare_provider->Username = name;
            $healthcare_provider->Password = pass;

            // get retrieved row
            $row = $stmt1->fetch(PDO::FETCH_ASSOC);

            // create array
            $healthcare_provider=array(
                "status" => true,
                "message" => "Successfully Login!",
                "Username" => $row['Username'],
                "Password" => $row['Password']
            );

            
        }


        if($stmt2->rowCount() == true) {
            // set ID property of user to be edited
            $patient->Username = name;
            $patient->Password = pass;

            // get retrieved row
            $row = $stmt2->fetch(PDO::FETCH_ASSOC);

            // create array
            $patient=array(
                "status" => true,
                "message" => "Successfully Login!",
                "Username" => $row['Username'],
                "Password" => $row['Password']
            );

            header("Location: ../../Patient/index.php");
            exit;
        }

        if($stmt3->rowCount() == true) {
            // set ID property of user to be edited
            $va_employee->Username = name;
            $va_employee->Password = pass;

            // get retrieved row
            $row = $stmt3->fetch(PDO::FETCH_ASSOC);

            // create array
            $va_employee_arr=array(
                "status" => true,
                "message" => "Successfully Login!",
                "Username" => $row['Username'],
                "Password" => $row['Password']
            );

            header("Location: ../../VA_Employee/index.php");
            exit;
        }
    }
    else{
        echo("FAT CUNT");
    }

    // make it json format
    //print_r(json_encode($va_employee_arr));
    ?>