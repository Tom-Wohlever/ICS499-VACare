<?php
 
// include database and object files
include_once '../config/database.php';
include_once '../objects/healthcare_provider.php';
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare provider object
$healthcare_provider = new Healthcare_Provider($db);
 
// set provider property values
$healthcare_provider->Healthcare_Provider_Name_Last = $_POST['Healthcare_Provider_Name_Last'];
 
// remove the provider
if($healthcare_provider->delete()){
    $healthcare_provider_arr=array(
        "status" => true,
        "message" => "Successfully Removed!"
    );
}
else{
    $patient_arr=array(
        "status" => false,
        "message" => "Healthcare Provider Cannot be deleted."
    );
}
print_r(json_encode($healthcare_provider_arr));
?>