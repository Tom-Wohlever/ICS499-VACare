<?php
 
// get database connection
include_once '../config/database.php';
 
// instantiate user object
include_once '../objects/va_employee.php';
 
$database = new Database();
$db = $database->getConnection();
 
$va_employee = new VA_Employee($db);
 
// set user property values
$va_employee->VA_Employee_Name_First = $_POST['VA_Employee_Name_First'];
$va_employee->VA_Employee_Name_Last = $_POST['VA_Employee_Name_Last'];
$va_employee->Job_Title = $_POST['Job_Title'];
$va_employee->Address_Street = $_POST['Address_Street'];
$va_employee->Address_City = $_POST['Address_City'];
$va_employee->Address_State = $_POST['Address_State'];
$va_employee->Username = $_POST['Username'];
$va_employee->Password = $_POST['Password'];
 
// create the user
if($va_employee->signup()){
    $va_employee=array(
        "status" => true,
        "message" => "Successfully Signup!",
        "Username" => $va_employee->Username
    );
}
else{
    $va_employee_arr=array(
        "status" => false,
        "message" => "User already exists!"
    );
}
print_r(json_encode($va_employee_arr));
?>