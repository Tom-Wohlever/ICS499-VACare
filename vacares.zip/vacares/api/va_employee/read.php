<?php
// include database and object files
include_once '../config/database.php';
include_once '../objects/va_employee.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare employee object
$va_employee = new VA_Employee($db);

// query employee
$stmt = $va_employee->read();
$num = $stmt->rowCount();
echo($num);
// check if more than 0 record found
if($num>0){
 
    // employees array
    $va_employees_arr=array();
    $va_employees_arr["va_employees"]=array();
 
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        $va_employee_item=array(
            "VA_Employee_Name_First" => $VA_Employee_Name_First,
            "VA_Employee_Name_Last" => $VA_Employee_Name_Last,
            "Job_Title" => $Job_Title,
            "Address_Street" => $Address_Street,
            "Address_City" => $Address_City,
            "Address_State" => $Address_State
        );
        array_push($va_employees_arr["va_employees"], $va_employee_item);
    }
 
    echo json_encode($va_employees_arr["va_employees"]);
}
else{
    echo json_encode(array());
}
?>