<?php
 
// include database and object files
include_once '../config/database.php';
include_once '../objects/va_employee.php';
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare patient object
$va_employee = new VA_Employee($db);
 
// set patient property values
$va_employee->VA_Employee_Name_Last = $_POST['VA_Employee_Name_Last'];
 
// remove the patient
if($va_employee->delete()){
    $va_employee_arr=array(
        "status" => true,
        "message" => "Successfully Removed!"
    );
}
else{
    $va_employee_arr=array(
        "status" => false,
        "message" => "VA Employee Cannot be deleted."
    );
}
print_r(json_encode($va_employee_arr));
?>