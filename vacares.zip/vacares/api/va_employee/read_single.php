<?php
// include database and object files
include_once '../config/database.php';
include_once '../objects/healthcare_provider.php';

// get database connection
$database = new Database();
$db = $database->getConnection();

// prepare provider object
$healthcare_provider = new Healthcare_Provider($db);
// set ID property of employee to be edited
$healthcare_provider->Healthcare_Provider_Name_Last = isset($_GET['Healthcare_Provider_Name_Last']) ? $_GET['Healthcare_Provider_Name_Last'] : die();
// read the details of provider to be edited
$stmt = $healthcare_provider->read_single();
if($stmt->rowCount() > 0){
    // get retrieved row
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // create array
    $healthcare_provider_arr=array(
        "Healthcare_Provider_Name_First" => $row['Healthcare_Provider_Name_First'],
        "Healthcare_Provider_Name_Last" => $row['Healthcare_Provider_Name_Last'],
        "Job_Title" => $row['Job_Title'],
        "Address_Street" => $row['Address_Street'],
        "Address_City" => $row['Address_City'],
        "Address_State" => $row['Address_State']
    );
}
// make it json format
print_r(json_encode($va_employee_arr));
?>