<?php
// include database and object files
include_once '../config/database.php';
include_once '../objects/va_employee.php';
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare employee object
$va_employee = new VA_Employee($db);
 
// set employee property values
$va_employee->VA_Employee_Name_First = $_POST['VA_Employee_Name_First'];
$va_employee->VA_Employee_Name_Last = $_POST['VA_Employee_Name_Last'];
$va_employee->Job_Title = $_POST['Job_Title'];
$va_employee->Address_Street = $_POST['Address_Street'];
$va_employee->Address_City = $_POST['Address_City'];
$va_employee->Address_State = $_POST['Address_State'];

// create the patient
if($va_employee->create()){
    $va_employee_arr=array(
        "status" => true,
        "message" => "Successfully Signup!",
        "VA_Employee_Name_First" => $va_employee->VA_Employee_Name_First,
        "VA_Employee_Name_Last" => $va_employee->VA_Employee_Name_Last,
        "Job_Title" => $va_employee->Job_Title,
        "Address_Street" => $va_employee->Address_Street,
        "Address_City" => $va_employee->Address_City,
        "Address_State" => $va_employee->Address_State
    );
}
else{
    $va_employee_arr=array(
        "status" => false,
        "message" => "VA Employee already exists!"
    );
}
print_r(json_encode($va_employee_arr));
?>