    <?php
    // include database and object files
    include_once '../config/database.php';
    include_once '../objects/healthcare_provider.php';
    include_once '../objects/patient.php';
    include_once '../objects/va_employee.php';
    include_once '../objects/user.php';

    // get database connection
    $database = new Database();
    $db = $database->getConnection();

    // prepare user object
    $healthcare_provider = new Healthcare_Provider($db);
    $patient = new Patient($db);
    $va_employee = new VA_Employee($db);
    $user = new User($db);

    // store ID property of user to be edited
    $name = isset($_GET['Username']) ? $_GET['Username'] : die();
    $pass = isset($_GET['Password']) ? $_GET['Password'] : die();

    // read the details of user to be edited

    $stmt = $user->login();
    echo("Hello");
    if($stmt->rowCount() > 0) {

        $type_array["type"]=array();
        $password_array["password"] = array();
        $username_array["user"]=array();

        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);

            $usernameExtracted = $Username;
            $passwordExtracted = $Password;
            $typeExtracted = $UType;

            array_push($username_array["user"], $usernameExtracted);
            array_push($password_array["password"], $passwordExtracted);
            array_push($type_array["type"], $typeExtracted);

        }


        for($i = 0; $i < count($username_array["user"]); $i++){
            echo($type_array["type"][$i]);

            if($name == $username_array["user"][$i] && $pass == $password_array["password"][$i]){

                if($type_array["type"][$i] == 1){
                    header("Location: ../../VA_Employee/index.php");
                    exit;
                }
                if($type_array["type"][$i] == 2){
                    header("Location: ../../Patient/index.php");
                    exit;
                }

            }

        }

    }
    else{
        echo("Login Error");
    }
    ?>