<?php
class Healthcare_Provider{

    // database connection and table name
    private $conn;
    private $table_name = "healthcare_providers";
 
    // object properties
    public $Healthcare_Provider_Name_First;
    public $Healthcare_Provider_Name_Last;
    public $Job_Title;
    public $Address_Street;
    public $Address_City;
    public $Address_State;
    public $Username;
    public $Password;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }

     // read all providers
    function read(){
        // select all query
        $query = "SELECT
                    `Healthcare_Provider_Name_First`, `Healthcare_Provider_Name_Last`, `Job_Title`, `Address_Street`, `Address_City`, `Address_State`
                FROM
                    " . $this->table_name . " 
                ORDER BY
                    Healthcare_Provider_Name_Last DESC";
    
        // prepare query statement
        $stmt = $this->conn->prepare($query);
    
        // execute query
        $stmt->execute();
    
        return $stmt;
    }

    // get single provider data
    function read_single(){
    
        // select all query
        $query = "SELECT
                    `Healthcare_Provider_Name_First`, `Healthcare_Provider_Name_Last`, `Job_Title`, `Address_Street`, `Address_City`, `Address_State`
                FROM
                    " . $this->table_name . " 
                WHERE
                    Healthcare_Provider_Name_Last= '".$this->VA_Employee_Name_Last."'";
    
        // prepare query statement
        $stmt = $this->conn->prepare($query);
    
        // execute query
        $stmt->execute();
        return $stmt;
    }

    // direct user by type to their respective web page
    function direct_login() {

        // select all query
        $query = "SELECT
                    `Username`, `Password`
                FROM
                    " . $this->table_name . " 
                WHERE
                    Username= '".$this->Username."'";
    
        // prepare query statement
        $stmt = $this->conn->prepare($query);
    
        // execute query
        $stmt->execute();
        return $this->table_name;
    }

    // create provider
    function create(){
    
        if($this->isAlreadyExist()){
            return false;
        }
        
        // query to insert record
        $query = "INSERT INTO  ". $this->table_name ." 
                        (`Healthcare_Provider_Name_First`, `Healthcare_Provider_Name_Last`, `Job_Title`, `Address_Street`, `Address_City`, `Address_State`)
                  VALUES
                        ('".$this->Healthcare_Provider_Name_First."', '".$this->Healthcare_Provider_Name_Last."', '".$this->Job_Title."', '".$this->Address_Street."', '".$this->Address_City."', '".$this->Address_State."')";
    
        // prepare query
        $stmt = $this->conn->prepare($query);
    
        // execute query
        if($stmt->execute()){
            $this->Healthcare_Provider_Name_Last = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    // delete provider
    function delete(){
        
        // query to insert record
        $query = "DELETE FROM
                    " . $this->table_name . "
                WHERE
                    Healthcare_Provider_Name_Last= '".$this->Healthcare_Provider_Name_Last."'";
        
        // prepare query
        $stmt = $this->conn->prepare($query);
        
        // execute query
        if($stmt->execute()){
            return true;
        }
        return false;
    }

    function isAlreadyExist(){
        $query = "SELECT *
            FROM
                " . $this->table_name . " 
            WHERE
                Healthcare_Provider_Name_Last='".$this->Healthcare_Provider_Name_Last."'";
        // prepare query statement
        $stmt = $this->conn->prepare($query);
        // execute query
        $stmt->execute();
        if($stmt->  rowCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }
    
    function signup(){
    if($this->isAlreadyExist()){
        return false;
    }
    // query to insert record
    $query = "INSERT INTO  ". $this->table_name ." 
                        (`Healthcare_Provider_Name_First`, `Healthcare_Provider_Name_Last`, `Job_Title`, `Address_Street`, `Address_City`, `Address_State`, `Username`, `Password`)
                  VALUES
                        ('".$this->Healthcare_Provider_Name_First."', '".$this->Healthcare_Provider_Name_Last."', '".$this->Job_Title."', '".$this->Address_Street."', '".$this->Address_City."', '".$this->Address_State."', '".$this->Username."', '".$this->Password."')";
    // prepare query
    $stmt = $this->conn->prepare($query);
    // sanitize
    $this->Healthcare_Provider_Name_First=htmlspecialchars(strip_tags($this->Healthcare_Provider_Name_First));
    $this->Healthcare_Provider_Name_Last=htmlspecialchars(strip_tags($this->Healthcare_Provider_Name_Last));
    $this->Job_Title=htmlspecialchars(strip_tags($this->Job_Title));
    $this->Address_Street=htmlspecialchars(strip_tags($this->Address_Street));
    $this->Address_City=htmlspecialchars(strip_tags($this->Address_City));
    $this->Address_State=htmlspecialchars(strip_tags($this->Address_State));
    $this->Username=htmlspecialchars(strip_tags($this->Username));
    $this->Password=htmlspecialchars(strip_tags($this->Password));
    // bind values
    $stmt->bindParam(":Username", $this->Username);
    $stmt->bindParam(":Password", $this->Password);

    // execute query
    if($stmt->execute()){
        $this->id = $this->conn->lastInsertId();
        return true;
    }
    return false;

    }
    
    function login(){
    // select all query
    $query = "SELECT
                `Username`, `Password`
            FROM
                " . $this->table_name . " 
            WHERE
                Username='".$this->Username."' AND Password='".$this->Password."'";
    // prepare query statement
    $stmt = $this->conn->prepare($query);
    // execute query
    $stmt->execute();
    return $stmt;
    }
}