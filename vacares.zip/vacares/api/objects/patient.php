<?php
class Patient{

    // database connection and table name
    private $conn;
    private $table_name = "patients";
 
    // object properties
    public $Patient_Name_First;
    public $Patient_Name_Last;
    public $Rank;
    public $Branch;
    public $Component;
    public $Address_Street;
    public $Address_City;
    public $Address_State;
    public $Distance;
    public $Eligible;
    public $Username;
    public $Password;
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }

     // read all patients
    function read(){
        // select all query
        $query = "SELECT
                    `Patient_Name_First`, `Patient_Name_Last`, `Rank`, `Branch`, `Component`, `Address_Street`, `Address_City`, `Address_State`
                FROM
                    " . $this->table_name . " 
                WHERE Eligible = 'Yes'
                ORDER BY
                    Patient_Name_Last DESC";
    
        // prepare query statement
        $stmt = $this->conn->prepare($query);
    
        // execute query
        $stmt->execute();
    
        return $stmt;
    }

    // get single patient data
    function patient_read(){
    
        // select all query
        $query = "SELECT
                    `Diagnosis`, `Prescriptions`
                FROM
                    " . $this->table_name . "
                WHERE
                    Patient_Name_Last= '".$this->Patient_Name_Last."'";
    
        // prepare query statement
        $stmt = $this->conn->prepare($query);
    
        // execute query
        $stmt->execute();
        return $stmt;
    }
    // create patient
    function create(){
    
        if($this->isAlreadyExist()){
            return false;
        }
        
        // query to insert record
        $query = "INSERT INTO  ". $this->table_name ." 
                        (`Patient_Name_First`, `Patient_Name_Last`, `Rank`, `Branch`, `Component`, `Address_Street`, `Address_City`, `Address_State`)
                  VALUES
                        ('".$this->Patient_Name_First."', '".$this->Patient_Name_Last."', '".$this->Rank."', '".$this->Branch."', '".$this->Component."', '".$this->Address_Street."', '".$this->Address_City."', '".$this->Address_State."')";
    
        // prepare query
        $stmt = $this->conn->prepare($query);
    
        // execute query
        if($stmt->execute()){
            $this->Patient_Name_Last = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    function isAlreadyExist(){
        $query = "SELECT *
            FROM
                " . $this->table_name . " 
            WHERE
                Patient_Name_Last='".$this->Patient_Name_Last."'";
        // prepare query statement
        $stmt = $this->conn->prepare($query);
        // execute query
        $stmt->execute();
        if($stmt->rowCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }

    function signup(){
    //if($this->isAlreadyExist()){
    //    return false;
    //}
    if($this->Distance < 21) {
        $this->Eligible = 'No';
    }
    if($this->Distance > 20) {
        $this->Eligible = 'Yes';
    }

    // query to insert record
    $query = "INSERT INTO  
                ". $this->table_name ." 
                SET
                        Patient_Name_First=:Patient_Name_First, Patient_Name_Last=:Patient_Name_Last, Rank=:Rank, Branch=:Branch, Component=:Component, Address_Street=:Address_Street, Address_City=:Address_City, Address_State=:Address_State, Distance=:Distance, Eligible=:Eligible, Username=:Username, Password=:Password,";
    // prepare query
    $stmt = $this->conn->prepare($query);
    // sanitize
/*    $this->Patient_Name_First=htmlspecialchars(strip_tags($this->Patient_Name_First));
    $this->Patient_Name_Last=htmlspecialchars(strip_tags($this->Patient_Name_Last));
    $this->Rank=htmlspecialchars(strip_tags($this->Rank));
    $this->Branch=htmlspecialchars(strip_tags($this->Branch));
    $this->Component=htmlspecialchars(strip_tags($this->Component));
    $this->Address_Street=htmlspecialchars(strip_tags($this->Address_Street));
    $this->Address_City=htmlspecialchars(strip_tags($this->Address_City));
    $this->Address_State=htmlspecialchars(strip_tags($this->Address_State));
    $this->Username=htmlspecialchars(strip_tags($this->Username));
    $this->Password=htmlspecialchars(strip_tags($this->Password)); */
    // bind values
    $stmt->bindParam(":Patient_Name_First", $this->Patient_Name_First);
    $stmt->bindParam(":Patient_Name_Last", $this->Patient_Name_Last);
    $stmt->bindParam(":Rank", $this->Rank);
    $stmt->bindParam(":Branch", $this->Branch);
    $stmt->bindParam(":Component", $this->Component);
    $stmt->bindParam(":Address_Street", $this->Address_Street);
    $stmt->bindParam(":Address_State", $this->Address_State);
    $stmt->bindParam(":Address_State", $this->Address_State);
    $stmt->bindParam(":Distance", $this->Username);
    $stmt->bindParam(":Eligible", $this->Password);
    $stmt->bindParam(":Username", $this->Username);
    $stmt->bindParam(":Password", $this->Password);

    // execute query
    // prepare query
        $stmt = $this->conn->prepare($query);
    
        // execute query
        if($stmt->execute()){
            $this->Patient_Name_Last = $this->conn->lastInsertId();
            return true;
        }
        return false;
    

    }

    function login(){
    // select all query
    $query = "SELECT
                `Username`, `Password`
            FROM
                " . $this->table_name . " 
            WHERE
                Username='".$this->Username."' AND Password='".$this->Password."'";
    // prepare query statement
    $stmt = $this->conn->prepare($query);
    // execute query
    $stmt->execute();
    return $stmt;
    }
}