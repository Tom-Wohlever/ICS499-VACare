<?php
class User{

    // database connection and table name
    private $conn;
    private $table_name = "user";
 
    // object properties
    public $Username;
    public $Password;
    public $UType;
    public $numRows;
    
 
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }


    // direct user by type to their respective web page
    function direct_login() {

        // select all query
        $query = "SELECT
                    `Username`, `Password`
                FROM
                    " . $this->table_name . " 
                WHERE
                    Username= '".$this->Username."'";
    
        // prepare query statement
        $stmt = $this->conn->prepare($query);
    
        // execute query
        $stmt->execute();
        return $this->table_name;
    }
    
    function login(){
    // select all query
    $query = "SELECT `Username`, `Password`, `UType` FROM " . $this->table_name;
    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // execute query
    $stmt->execute();
    return $stmt;
    }
}