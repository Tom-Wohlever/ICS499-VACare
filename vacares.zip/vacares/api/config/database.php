<?php
class Database{
 
    // specify your own database credentials
    private $host = "http://localhost:8000/";
	private $port = "8000";
    private $db_name = "va_db";
    private $username = "root";
    private $password = "ics311";
    public $conn;

    // get the database connection
    public function getConnection(){
 
        $this->conn = null;
 
 /*       if($conn->connect_error) {
            die("Connection Error: " . $conn->connect_error);
        }
        echo "Connection Success";
*/
        try{
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name . ';port=' . $this->port, $this->username, $this->password);
            $this->conn->exec("set names utf8");
            echo "Connection Successful";
        }catch(PDOException $exception){
            echo "Connection error: " . $exception->getMessage();
        }
        return $this->conn;
    }
}
?>